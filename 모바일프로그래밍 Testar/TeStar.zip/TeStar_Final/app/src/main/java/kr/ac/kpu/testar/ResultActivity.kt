package kr.ac.kpu.testar

import android.content.Intent
import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import kotlinx.android.synthetic.main.test_result.*

class ResultActivity : AppCompatActivity(){

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.test_result)
        val intent = intent
        var kind:String
        kind=intent.getStringExtra("kind")
        when(kind){
            "camera" ->{
                var resultCamera :Boolean
                resultCamera=intent.getBooleanExtra("camResult",false)
                var remarkCamera : String
                remarkCamera=intent.getStringExtra("camExtra")
                if(resultCamera==true){
                    test.text="정상 동작"
                }
                else{
                    test.text="오작동"
                }
                remark.text=remarkCamera
                result.text="카메라 테스트 결과"
            }
            "sound" ->{
                var resultSound :Boolean
                resultSound=intent.getBooleanExtra("sndResult",false)
                var remarkSound : String
                remarkSound=intent.getStringExtra("sndExtra")
                if(resultSound==true){
                    test.text="정상 동작"
                }
                else{
                    test.text="오작동"
                }
                remark.text=remarkSound
                result.text="사운드 테스트 결과"
            }
            "network" ->{
                var resultNetwork :Boolean
                resultNetwork=intent.getBooleanExtra("netResult",false)
                var remarkNetwork : String
                remarkNetwork=intent.getStringExtra("netExtra")
                if(resultNetwork==true){
                    test.text="정상 동작"
                }
                else{
                    test.text="오작동"
                }
                remark.text=remarkNetwork
                result.text="네트워크 테스트 결과"
            }
            "touch" ->{
                var resultTouch :Boolean
                resultTouch=intent.getBooleanExtra("touchResult",false)
                if(resultTouch==true){
                    test.text="정상 동작"
                }
                else{
                    test.text="오작동"
                }
                result.text="터치 테스트 결과"
            }
            "mic" ->{
                var resultMic :Boolean
                resultMic=intent.getBooleanExtra("micResult",false)
                var remarkMic : String
                remarkMic=intent.getStringExtra("micExtra")
                if(resultMic==true){
                    test.text="정상 동작"
                }
                else{
                    test.text="오작동"
                }
                remark.text=remarkMic
                result.text="마이크 테스트 결과"
            }

        }

        goMain.setOnClickListener{
            val main = Intent(this, MainActivity::class.java)
            startActivity(main)
        }
    }
}