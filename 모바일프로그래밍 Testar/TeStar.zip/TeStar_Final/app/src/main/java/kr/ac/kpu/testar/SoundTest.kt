package kr.ac.kpu.testar

import android.content.Intent
import android.media.MediaPlayer
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Toast
import kotlinx.android.synthetic.main.activity_sound_test.*

class SoundTest : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_sound_test)
        setTitle("사운드 테스트")

        val aSample = MediaPlayer.create(this, R.raw.speaker)
        val resultIntent = Intent(this, ResultActivity::class.java)
        sndRtnBtn.setOnClickListener() {
            var sndCheck = sndRadioGroup.checkedRadioButtonId
            when (sndCheck) {
                R.id.sndWorks -> {
                    resultIntent.putExtra("kind", "sound")
                    resultIntent.putExtra("sndResult", true)
                    resultIntent.putExtra("sndExtra", sndText.text.toString())
                    startActivity(resultIntent)
                    finish()
                }
                R.id.sndDont -> {
                    resultIntent.putExtra("kind", "sound")
                    resultIntent.putExtra("sndResult", false)
                    resultIntent.putExtra("sndExtra", sndText.text.toString())
                    startActivity(resultIntent)
                    finish()
                }
                -1 -> Toast.makeText(this, "아무 것도 선택하지 않았습니다.", Toast.LENGTH_SHORT).show()
            }
        }
        playBtn.setOnClickListener() {
            aSample.start()
        }
    }
}
