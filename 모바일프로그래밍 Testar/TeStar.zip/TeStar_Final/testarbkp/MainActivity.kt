package kr.ac.kpu.testar

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import kotlinx.android.synthetic.main.activity_main.*
import kotlinx.android.synthetic.main.activity_main.camBtn

class MainActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        var newIntent : Intent
        sndBtn.setOnClickListener() {
            newIntent = Intent(this, SoundTest::class.java)
            startActivity(newIntent)
        }
        tchBtn.setOnClickListener() {
            newIntent = Intent(this, TouchTest::class.java)
            startActivity(newIntent)
        }
        nwkBtn.setOnClickListener() {
            newIntent = Intent(this, NetworkTest::class.java)
            startActivity(newIntent)
        }
        micBtn.setOnClickListener() {
            newIntent = Intent(this, MicTest::class.java)
                startActivity(newIntent)
        }
        camBtn.setOnClickListener() {
            newIntent = Intent(this, CameraTest::class.java)
            startActivity(newIntent)
        }

    }
/*
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        var
    }*/
}
