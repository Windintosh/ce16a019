package kr.ac.kpu.testar

import android.content.Intent
import android.net.Uri
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Toast
import kotlinx.android.synthetic.main.activity_network_test.*

class NetworkTest : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_network_test)

        setTitle("네트워크 테스트")

        val resultIntent = Intent(this, ResultActivity::class.java)

        conBtn.setOnClickListener() {
            val uri = Uri.parse("https://www.kpu.ac.kr")
            var intent = Intent(Intent.ACTION_VIEW, uri)
            startActivity(intent)
        }

        netRtnBtn.setOnClickListener() {
            var netCheck : Int = netRadioGroup.checkedRadioButtonId
            when(netCheck) {
                R.id.netWorks -> {
                    //Toast.makeText(this, "정상 동작.", Toast.LENGTH_SHORT).show()
                    resultIntent.putExtra("kind", "network")
                    resultIntent.putExtra("netResult", true)
                    resultIntent.putExtra("netExtra", netText.text.toString())
                    startActivity(resultIntent)
                }
                R.id.netDont -> {
                    //Toast.makeText(this, "오동작.", Toast.LENGTH_SHORT).show()
                    resultIntent.putExtra("kind", "network")
                    resultIntent.putExtra("netResult", false)
                    resultIntent.putExtra("netExtra", netText.text.toString())
                    startActivity(resultIntent)
                }
                -1 -> Toast.makeText(this, "아무 것도 선택하지 않았습니다.", Toast.LENGTH_SHORT).show()
            }
        }
    }
}
