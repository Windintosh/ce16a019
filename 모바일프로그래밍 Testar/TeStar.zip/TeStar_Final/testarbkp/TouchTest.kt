package kr.ac.kpu.testar

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.content.Intent
import android.widget.Button
import kotlinx.android.synthetic.main.touch_test.*


class TouchTest : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.touch_test)
        val buttons=arrayOfNulls<Button>(1000)
        val flags=Array<Boolean>(40) {false}

        var flag:Boolean=true
        for(i in 0..39){
            val buttonId:String = "button" +(i+1)
            buttons[i]=findViewById(getResources().getIdentifier(buttonId, "id", getPackageName()))
            buttons[i]?.setOnClickListener{
                flags[i]=true
            }
        }
        /*touchL.setOnTouchListener(object: View.OnTouchListener{
            override fun onTouch(v:View?,event:MotionEvent?):Boolean{
                when(event?.action){
                    MotionEvent.ACTION_DOWN -> {
                        return true
                        flag=true}
                    MotionEvent.ACTION_MOVE -> {
                        return true
                        flag=true}
                    MotionEvent.ACTION_UP -> {
                        return true
                        flag=true}
                    else -> {
                        return false
                        flag=false
                    }
                }
            }})*/

        returnBtn.setOnClickListener{
            val intent=Intent(this, ResultActivity::class.java)
            for(i in 0..39){
                if(flags[i]==false){
                    flag=false
                    break;
                }
            }
            intent.putExtra("kind","touch")
            intent.putExtra("touchResult",flag)
            startActivity(intent)
        }
        }



    /*
    override fun onTouchEvent(ev: MotionEvent): Boolean{
        when(ev.actionMasked){
            MotionEvent.ACTION_DOWN -> {
                return true
                flag=true}
            MotionEvent.ACTION_MOVE -> {
                return true
                flag=true}
            MotionEvent.ACTION_UP -> {
                return true
                flag=true}
            else -> {
                return false
                flag=false
            }
        }


    }
*/

}









