package kr.ac.kpu.testar

import android.content.Intent
import android.os.Bundle
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import kotlinx.android.synthetic.main.activity_result.*
import kr.ac.kpu.testar.R

class Result : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_result)

        setTitle("테스트 결과")

        val intent = intent
        var sound : Int = intent.getIntExtra("sndResult", -1)
        var sExtra : String? = intent.getStringExtra("sndExtra")
        when (sound) {
            R.id.sndWorks -> {
                Toast.makeText(this, "전달 완료", Toast.LENGTH_SHORT).show()
                sndFinal.text = "정상 동작"
                sndExtra.text = sExtra
            }
            R.id.sndDont -> {
                Toast.makeText(this, "전달 완료", Toast.LENGTH_SHORT).show()
                sndFinal.text = "오동작"
                sndExtra.text = sExtra
            }
            -1 -> {
                Toast.makeText(this, "오류 발생", Toast.LENGTH_SHORT).show()
                finish()
            }
        }
    }
}
